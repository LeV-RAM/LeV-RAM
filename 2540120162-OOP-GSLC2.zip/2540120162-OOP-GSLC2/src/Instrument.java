
public class Instrument { // Parent class
	String name;
	double price;
	public Instrument(String name, double price) {
		this.name = name;
		this.price = price;
	}
	
	public void showDetails() { // Show the details of the instrument
	}
}
