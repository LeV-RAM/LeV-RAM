
public interface Play {
	public abstract String playInstrument();
}
